import Axios from 'axios'


Axios.defaults.baseURL = 'http://172.16.10.25:8080/uhome';//配置向服务器发起请求的地址和端口
// 请求拦截


Axios.interceptors.request.use(
  //通用的配置
  config => {
    //把token添加到header
      let token = sessionStorage.getItem('token');
        // console.log(token);
        // console.log(config);
        config.headers.Authorization  = token;
        // console.log( config.headers.Authorization);

        return config;
  },
  error => {
    return Promise.reject(error)
  }
);

//响应拦截
Axios.interceptors.response.use(
  config => {
    //响应的token值储存
    return config
  }
);

export default Axios