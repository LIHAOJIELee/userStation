//主接口文件
import user from "./user"

export default {
  user
}