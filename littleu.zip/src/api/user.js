// user相关接口
export default {
  userLogin: '/user/login'
}